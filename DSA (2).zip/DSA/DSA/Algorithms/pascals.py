
# n = 5 
# spaces=5 
# for i in range(1, n+1): 
#     for j in range(0, spaces): 
#         print(' ', end='') 
 
#     # first element is always 1 
#     C = 1 
#     for j in range(1, i+1): 
 
#         # first value in a line is always 1 
#         print(' ', C, sep='', end='') 
 
#         # using Binomial Coefficient 
#         C = C * (i - j) // j 
#     spaces-=1 
#     print() 


n=5
spaces=5
for i in range (1,n+1):
    for j in range (0,spaces):
        print(' ', end='')


    c=1
    for j in range(1,i+1):
        print(' ', c, sep='', end='')


        c=c*(i-j)//j
    spaces=spaces-1
    print()