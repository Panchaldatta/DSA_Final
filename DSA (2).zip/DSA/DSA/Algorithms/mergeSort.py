class Mergesort:
   
    def merge_sort(self,list): 
       
        if len(list)<=1:
            return list
       
        mid=len(list)//2
        
        l_half=self.merge_sort(list[:mid])
        
        
        r_half=self.merge_sort(list[mid:])
        
        return self.merge(l_half,r_half)
    
    
    def merge(self,left,right):
        
        new=[]
        i,j=0,0
       
        while i<len(left) and j<len(right):
            
            if left[i]<right[j]:
                new.append(left[i])
                i+=1
           
            else:
                new.append(right[j])
                j+=1
        new.extend(left[i:])
        new.extend(right[j:])

        return new
    
sort=Mergesort()
l=[8,3,5,6,2,7]
print(l)
print(sort.merge_sort(l))