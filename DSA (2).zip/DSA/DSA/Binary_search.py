# def binary_search(l,n):
#     ''' 
#     binary search sathi sorted list pahije asti mhnun ith sort keli list 
#     built in function vaprla ahe jar te inputch sorted list ghya tr ya step chi garaj nahi
#     kiva mhnle builtin function nahi pahije tr mg joh sort sopa vatato to karaych'''
#     sorted_list=sorted(l) 
#     '''
#     left variable madhe 1st index store kela'''
#     left=0
#     '''
#     right variable madhe last index store kela'''
#     right=len(l)-1
#     '''
#     joparyant left chi value right peksha lahan ahe while loop run kela'''
#     while left<= right:
#         ''' 
#         Calculate mid'''
#         mid=(left+right)//2
#         '''
#         jar mid index cha element ani search kartoy toh element equal asal tar print element found'''
#         if(sorted_list[mid]==n):
#             print(f"element {n} found in list")
#             return mid
#         # jar mid index cha element motha asal tr left part madhi search karav lagal mhnun right=mid-l kela
#         elif (sorted_list[mid]>n):
#             right=mid-1
#         # jar mid index cha element chota asal tr right part madhi search karav lagal mhnun right=mid+l kela
#         else:
#             left=mid+1
#     #jar element present nasal tr element not found kela
#     print("element not found")

# l=[2,5,3,4,9,6]
# n=6
# binary_search(l,n)




def binary_search(l,n):
    sorted_list=sorted(l)
    left=0
    right=len(l)-1

    while left<=right:
        mid=(left+right)//2

        if (sorted_list[mid]==n):
            print(f"element {n} found in list")
            return mid
        elif(sorted_list[mid]>n):
            right=mid-1
        else:
            left=mid+1
    print("element not found ")
l=[1,2,3,4,5,6,7]
n=4
binary_search(l,n)

       


