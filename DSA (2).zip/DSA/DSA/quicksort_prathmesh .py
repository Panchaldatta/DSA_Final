'''hai pan recursive sort ahe pan yat apan partition vaprto
yat apn pivot element select karto ani ashe partition karto
ki pivot chya left side la sagle less than pivot element 
and pivot chya right side la sagle greater that pivot element'''

#quicksort method 3 parameter gheti array low ani high
#yat low mhnje element at start ani high mhnje element at end
def quicksort(arr,low,high):
    #jar low <high asal tar continue execution or stop
    if low<high:
        #partition method la call kela 
        #partition method pivot return karti to store kela variable madhe
        pivot=partition(arr,low,high)
        #left partition madhe quicksort method call keli
        #low cha pointer as it is ani high cha pointer pivot - 1
        quicksort(arr,low,pivot-1)
        #right partition madhe quicksort method call keli
        #low sathi pivot - 1 ani high as it is
        quicksort(arr,pivot+1,high)

#partition method pan same 3 parameters gheti
def partition(arr,low,high):
    #pivot navachya variable madhe 1 st index chi value store keli
    pivot=arr[low]
    #i counter la low + 1 assign kela
    i=low+1
    # j counter la high assign kela
    j=high

    # while loop chalacala up untill break
    while True:

        # another while loop 
        # joparyant i<=j and arr[i] chi value pivot peksha less ahe
        # i counter increment karaych
        while i<=j and arr[i]<=pivot:
            i+=1
        #tyanantar joparyant i<=j ani arr[j]>=pivot ahe
        #toparyant j counter decrement karaych
        while i<=j and arr[j]>=pivot:
            j-=1
        #jar i j peksha less asal tar arr[i] ani arr[j] swap karaych
        if i<=j:
            arr[i],arr[j]=arr[j],arr[i]
        # nahitar loop break karaych
        else:
            break
    # last la arr[low] ani arr[j] swap karaych
    arr[low],arr[j]=arr[j],arr[low]
    #j return karaych as a pivot element ata pudche partition j chya left ani right side madhe padatil
    return j

l=[1,5,3,7,4,9]
quicksort(l,0,len(l)-1)
print(l)