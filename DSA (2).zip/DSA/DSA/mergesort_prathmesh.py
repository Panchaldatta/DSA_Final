class Mergesort:
    '''
    merge sort work karto divide and conqueor method var 
    '''
    """
    yaat 2 methods astat ek divide karaysathi ani ek sort karun merge karaysathi """
    '''
    merge_sort method divide karaysathi ani merge method call karaysathi use karto yat list input gheychi'''
    def merge_sort(self,list): 
        """
        jar list chi length 1 or less than one asal tar list return karaychu """
        if len(list)<=1:
            return list
        """
        jar length 1 nasal tar mid find karaych list 2 part madhi divide karaychi"""
        mid=len(list)//2
        """
        left half sathi merge sort function call karaych 
        ani tyala list pass karaychi 1 st index pasun mid paryant
        ani result store karaych l_half madhi"""
        l_half=self.merge_sort(list[:mid])
        
        """
        right half sathi merge sort function call karaych 
        ani tyala list pass karaychi mid pasun  last index paryant
        ani result store karaych r_half madhi """
        r_half=self.merge_sort(list[mid:])
        """
        last la merge function return karaych ani tya function la l_half ani r_half pass karayche"""
        return self.merge(l_half,r_half)
    
    """
    hai function sorting ani merging sathi ahe 
    yala apan mergesort madhi 2 parameters pass kelet l_half ani r_half"""
    def merge(self,left,right):
        """
        ek empty lis create keli ani 2 temporary variables ani tyana 0 value assign keli
        i counter left sathi ahe
        j counter right sathi ahe"""
        new=[]
        i,j=0,0
        """
        while loop chalavla joparyant lef kiva right chi length i ani j peksha kami ahe toparyant"""
        while i<len(left) and j<len(right):
            """
            jar left[i] chi value right[j] peksha less asal 
            tar temporary list madhi left[i] append kara
            ani i counter increment kar"""
            if left[i]<right[j]:
                new.append(left[i])
                i+=1
            #otherwise temporary list madhe right[j] chi value append kara
            #j counter increment kara i 
            else:
                new.append(right[j])
                j+=1
        #while loop terminate zalyavar jya remaning value astil tya temporary list madhe takun dya
        new.extend(left[i:])
        new.extend(right[j:])

        #temporary list return kara
        return new
    
sort=Mergesort()
l=[8,3,5,6,2,7]
print(l)
print(sort.merge_sort(l))