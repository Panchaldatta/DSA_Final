class BST:
    def __init__(self,data):
        self.left=None 
        self.data=data
        self.right=None
    

    def insert_node(self,new_node):
        if new_node.data<self.data:
            if self.left is None:
                self.left=new_node
                print(f"Node Inserted: {new_node.data}")
            else:
                self.left.insert_node(new_node)
        else:
            if self.right is None:
                self.right=new_node
                print(f"Node Inserted: {new_node.data}")

            else:
                self.right.insert_node(new_node)


bst=BST(25)
bst.insert_node(BST(10))
bst.insert_node(BST(30))
bst.insert_node(BST(4))
bst.insert_node(BST(35))

print()

