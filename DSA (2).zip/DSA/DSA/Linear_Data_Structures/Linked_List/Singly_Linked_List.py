class Node:
    def __init__(self, data):
        self.data = data  # for assigning the data
        self.next = None  # assign 'next' as null initially
        # self.prev = None  # assign 'prev' as null initially

class SinglyLinkedList:
    def __init__(self):
        self.head = None  # assign 'head' as null initially

    def append(self, node_value):  # method to append elements at end of singly linked list
        temp = self.head  # points to 1st node
        if temp:
            while temp.next:  # find last node
                temp = temp.next
            temp.next = node_value  # appending new node
        else:
            self.head = node_value  # add first node to the singly linked list

    def insert(self, node_value, pos):  # method to insert element at specified position
        temp = self.head
        count = 1
        if pos == 1:
            node_value.next = self.head  # making new node as head
            self.head = node_value
        else:
            while temp:
                if count+1 == pos:  # to stop the singly linked list at 1 node before
                    node_value.next = temp.next
                    temp.next = node_value
                    return
                else:  # keep traversing
                    temp = temp.next
                    count += 1
                if temp is None:  # element not found in the singly linked list
                    print("Please enter a valid position")
                    return

    def delete(self, value):  # method to delete a specific element from the singly linked list
        temp = self.head  # points to the 1st node
        prev = None
        if temp.data == value:  # node at 1st position
            self.head = temp.next
        else:  # for deleting the node other than 1st position
            while temp:
                if temp.data == value:  # if node is found
                    break
                prev = temp
                temp = temp.next  # go to the next element
                if temp is None:  # element not found in the singly linked list
                    print("Node is not present in the singly linked list")
                    return
            if temp:
                prev.next = temp.next  # create link between previous and next node
    
    def delete_last(self):
        # If the list is empty, do nothing
        if not self.head:
            return

        # If there's only one node, delete it
        if not self.head.next:
            self.head = None
            return

        # Traverse the list to find the second-to-last node
        temp = self.head
        while temp.next and temp.next.next:
            temp = temp.next

        # Remove the last node
        temp.next = None

        

    def print(self):  # method to print elements of singly linked list
        temp = self.head
        while temp:
            print(temp.data, end=" ")
            temp = temp.next

    def reverse(self):
        temp = self.head
        prev = None
        while temp:
            next_node = temp.next  
            temp.next = prev
            prev = temp
            temp = next_node
        self.head = prev    

    def count(self):  # method to get the count of nodes in the singly linked list
        temp = self.head
        count = 0
        while temp:
            count += 1
            temp = temp.next
        print(f"The number of nodes in the singly linked list is {count}")
    
    def min_max(self):  # method to get the min and max element in the singly linked list
        temp = self.head
        minimum, maximum = temp.data, temp.data  # min and max will point to the first node data
        while temp:
            if temp.data < minimum:
                minimum = temp.data
            if temp.data > maximum:
                maximum = temp.data
            temp = temp.next
        print(f"The minimum element in the singly linked list is {minimum}")
        print(f"The maximum element in the singly linked list is {maximum}")
    
    def search(self,value):
        temp = self.head
        while temp:
            if temp.data == value:
                print(f"Node {value} exists")
                return 
            temp = temp.next
        print(f"{value} does not exist")
        return
        
    def merge(self,other):
        if not self.head:
            self.head = other.head
            return
        if not other.head:
            return
        else:
            temp = self.head
            while temp:
                if temp.next is None:
                    temp.next = other.head
                    return
                temp = temp.next
    
    def evenOdd(self):
        temp = self.head
        even_count=0
        odd_count = 0
        while temp:
            if temp.data % 2 == 0:
                even_count+=1
            else:
                odd_count+=1
            temp = temp.next 
        print(f"The number of even value nodes are: {even_count} and odd value nodes are: {odd_count}")

    def delete_pos(self,pos):
        temp = self.head
        count = 1
        prev = None
        if pos == count:
            self.head = temp.next 
            return
        else:
            while temp:
                if pos == count:
                    prev.next = temp.next 
                    return
                prev = temp
                temp = temp.next
                count +=1
                if temp == None:
                    print("Enter a valid position")
                
        

ll = SinglyLinkedList()
n1 = Node(1)
n2 = Node(2)
n3 = Node(3)
n4 = Node(4)
ll.append(n1)
ll.append(n2)
ll.append(n3)
ll.append(n4)
ll.print()
print()
ll2 = SinglyLinkedList()
n5 = Node(5)
n6 = Node(6)
n7 = Node(7)
n8 = Node(8)
ll2.append(n5)
ll2.append(n6)
ll2.append(n7)
ll2.append(n8)
ll2.print()
print()
print()
# ll.insert(Node(15), 2)
ll.print()
print()
print()
ll.delete(15)
ll.print()
print()
print()
ll.reverse()
ll.print()
print()
print()
ll.count()
print()
ll.min_max()
# ll.delete_last()
ll.print()
print()
ll.search(50)
print()
ll.delete_pos(3)
ll.print()
print()
ll.evenOdd()
ll.merge(ll2)
ll.print()
