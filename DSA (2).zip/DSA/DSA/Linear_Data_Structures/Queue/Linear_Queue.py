
class Node:
    def __init__(self, value):
        self.data = value
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def push(self,new_node):
        if self.top is None:
            self.top = new_node
        else:
            new_node.next = self.top
            self.top = new_node

    def pop(self):
        temp = self.top
        if temp:
            print(f"Popped element: {temp.data}")
            self.top = temp.next  # will point to next element
            return temp.data
        else:
            print("Stack is empty")

    def is_empty(self):
        return self.top is None

    def printst(self):
        temp = self.top
        print("The stack elements are: ", end="")
        while temp:
            print(temp.data, end=" ")
            temp = temp.next
        print()

class LinearQueue:
    def __init__(self):
        self.front = self.rear = None

    def enqueue(self, new_node):  # for inserting node in queue
        if self.rear:
            self.rear.next = new_node
            self.rear = new_node  # updating rear pointer
        else:  # for first node
            self.front = self.rear = new_node
            return

    def print(self):
        temp = self.front
        while temp:
            print(temp.data, end=" ")
            temp = temp.next
        print()

    def search(self, val):
        temp = self.front
        while temp:
            if temp.data == val:
                return True
            temp = temp.next  
        return False

    def peek(self):
        temp = self.front
        print(temp.data)
        print()

    def dequeue(self):  # for deleting node in queue
        if self.rear is not None:
            removed_data = self.front.data
            temp = self.front
            print(f"The deleted node is {temp.data}")
            self.front = self.front.next
            if self.front is None:  # for deleting last node in queue
                self.rear = None
            return removed_data
        else:
            print("Queue is empty")

    def count(self):
        temp = self.front
        count = 0
        while temp:
            count +=1
            temp = temp.next
        return count
 
    def compare(self,other):
        temp = self.front
        temp2 = other.front 
        count = 0
        no_of_elements = self.count()
        no_of_elements2 = other.count()
        while temp and temp2:
            if temp.data == temp2.data:
                count +=1
                if count == no_of_elements and no_of_elements2:
                    return True
            temp  = temp.next 
            temp2 = temp2.next 
        else:
            return False
    
    def is_empty(self):
        return self.front is None

    def reverse(self):
        temp = self.front
        stack = Stack()
        
        # Push all elements of the queue onto the stack
        while not self.is_empty():
            stack.push(Node(self.dequeue()))

        while not stack.is_empty():
            self.enqueue(Node(stack.pop()))

    def merge(self,other):
        temp = self.front
        while temp.next:
            temp = temp.next 
        temp.next = other.front
        return 

    def no_Occ(self,val):
        temp = self.front
        count = 0
        while temp:
            if temp.data == val:
                count+=1
            temp = temp.next 
        return count

q1 = LinearQueue()
q2 = LinearQueue()
n4 = Node(10)
n5 = Node(20)
n6 = Node(40)
n7 = Node(40)
n1 = Node(10)
n2 = Node(20)
n3 = Node(30)
q1.enqueue(n1)
q1.enqueue(n2)
q1.enqueue(n3)
q2.enqueue(n4)
q2.enqueue(n5)
q2.enqueue(n6)
q2.enqueue(n7)

print("Queue 1: Initial State")
q1.print()  # Print the initial state of queue 1

print("\nQueue 2: Initial State")
q2.print()  # Print the initial state of queue 2

print("\nDequeue Operation on Queue 1")
q1.dequeue()  # Remove an element from queue 1
print("After dequeue, Queue 1:")
q1.print()

print("\nPeek Front Element in Queue 1")
if not q1.is_empty():
    print("Front element of Queue 1:")
    q1.peek()
else:
    print("Queue 1 is empty.")

print("\nComparing Queue 1 and Queue 2")
if q1.compare(q2):
    print("Queue 1 and Queue 2 are identical.")
else:
    print("Queue 1 and Queue 2 are not identical.")

print("\nSearching for Element (30) in Queue 1")
if q1.search(30):
    print("Element 30 found in Queue 1.")
else:
    print("Element 30 not found in Queue 1.")

print("\nQueue 1: Original State")
q1.print()

print("\nReversing Queue 1")
q1.reverse()
print("Queue 1 after reversing:")
q1.print()

print("\nMerging Queue 1 and Queue 2")
q1.merge(q2)
print("Queue 1 after merging with Queue 2:")
q1.print()

print("\nCounting Occurrences of Element (40) in Queue 1")
occurrences = q1.no_Occ(40)
print(f"Element 40 occurs {occurrences} time(s) in Queue 1.")


# q1 = LinearQueue()
# q2 = LinearQueue()
# n4 = Node(10)
# n5 = Node(20)
# n6 = Node(40)
# # n7 = Node(40)
# n1 = Node(10)
# n2 = Node(20)
# n3 = Node(30)
# q1.enqueue(n1)
# q1.enqueue(n2)
# q1.enqueue(n3)
# q2.enqueue(n4)
# q2.enqueue(n5)
# q2.enqueue(n6)
# q2.enqueue(n7)

# q1.print()
# q2.print()
# print()
# q1.dequeue()
# q1.print()
# q1.peek()
# if q1.compare(q2):
#     print("True")
# else:
#     print("false")
# # q2.print()
# print()
# if q1.search(30):
#     print("Found")
# else:
#     print("Not found")
# print("Original queue:")
# q1.print()  # Should print: 10 20 40

# q1.reverse()

# print("Reversed queue:")
# q1.print()  # Should print: 40 20 10
# q1.merge(q2)
# q1.print()
# print()
# print(q1.no_Occ(40))