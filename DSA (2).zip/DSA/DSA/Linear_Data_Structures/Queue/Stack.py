class Node:
    def __init__(self, value):
        self.data = value
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def push(self,new_node):
        if self.top is None:
            self.top = new_node
        else:
            new_node.next = self.top
            self.top = new_node

    def pop(self):
        temp = self.top
        if temp:
            print(f"Popped element: {temp.data}")
            self.top = temp.next  # will point to next element
            del temp  # will remove the top node
        else:
            print("Stack is empty")

    def print(self):
        temp = self.top
        print("The stack elements are: ", end="")
        while temp:
            print(temp.data, end=" ")
            temp = temp.next


    def reverse_str(self):
        st3 = Stack()
        str1 = input("Enter the string: ")
        for char in str1:
            n = Node(char)
            st3.push(n)
        temp = st3.top
        while temp:
            print(temp.data, end="")
            temp = temp.next

    def nextGr(self):
        temp = self.top
        list1 = []
        while temp:
            list1.append(temp.data)
            temp = temp.next 
        list1.sort()
        return list1.pop(-2)
    
    def sortSt(self):
        temp = self.top
        list2 = []
        while temp:
            list2.append(temp.data)
            temp = temp.next 
        list2.sort()
        self.top = None
        for item in list2:
            n = Node(item)
            self.push(n)



    def count(self):
        temp = self.top
        count = 0
        while temp:
            count +=1
            temp = temp.next
        return count

    def isEmpty(self):
        if self.top:
            return True
        else:
            return False

    
    def peek(self):
        temp = self.top
        return temp.data

    def reverse(self):
        st1 = Stack()  # create copy of stack
        temp = self.top
        while temp:
            new_node = Node(temp.data)  # create a new node with the same data
            st1.push(new_node)   # insert the new_node in the new stack
            temp = temp.next  # traverse the elements
        st1.print()   # print the new reversed stack

st2 = Stack()
st = Stack()
n1 = Node(10)
n2 = Node(20)
n3 = Node(30)
n4 = Node(40)
n5 = Node(35)
n6 = Node(25)
n7 = Node(60)
st.push(n1)
st.push(n2)
st.push(n3)
st.push(n4)
st.push(n5)
st.push(n6)
st.push(n7)
st.print()
print()
print()
st.pop()
st.print()
print()
print()
# st.reverse()
print()
print("the top most element in the stack is: ",st.peek())
print()
if st2.isEmpty():
    print("Stack is not empty")
else:
    print("Stack is empty")
print()
if st.isEmpty():
    print("Stack is not empty")
else:
    print("Stack is empty")
print()
print("The number of elements in the stack are: ",st.count())
st.reverse_str()
print()
st.print()
print()
print(st.nextGr())
st.print()
print()
st.sortSt()
st.print()
