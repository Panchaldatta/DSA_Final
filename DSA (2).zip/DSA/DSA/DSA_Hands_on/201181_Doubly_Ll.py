class Node:
    def __init__(self, data):
        self.data = data  
        self.next = None 
        self.prev = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None  # assign 'head' as null initially

    def append(self, node_value):  # method to append elements at end of doubly linked list
        temp = self.head  # points to 1st node
        if temp:
            while temp.next:  # find last node
                temp = temp.next
            temp.next = node_value  # appending new node
            node_value.prev = temp
        else:
            self.head = node_value  # add first node to the doubly linked list

    def print(self):  # method to print elements of doubly linked list
        temp = self.head
        while temp:
            print(temp.data, end=" ")
            temp = temp.next

    def reverse(self):
        temp = self.head
        prev = None
        # traverse all nodes of doubly linked list
        while temp:
            next_node = temp.next  # initially store the node value before reversing
            # reverse current node's next and prev pointer
            temp.next = prev
            temp.prev = next_node
            # move pointers one position ahead
            prev = temp
            temp = next_node
        self.head = prev  # update the head to the prev which is the last value after iteration

    def insert_begin(self, value):
        if self.head is None:  # If the list is empty, set the new node as the head
            self.head = value
            return
        else:
            # Insert the new node at the beginning
            value.next = self.head
            self.head.prev = value
            self.head = value  # Update the head to the new node

    def count(self):  # method to get the count of nodes in the singly linked list
        temp = self.head
        count = 0
        while temp:
            count += 1
            temp = temp.next
        return count

    def delete_middle(self):
        # Delete the middle node of the doubly linked list
        mid_pos = self.count() // 2  # Find the middle position
        temp = self.head
        count = 0

        # Traverse to the middle node
        while temp:
            if mid_pos == count:
                break
            prev = temp
            temp = temp.next
            count += 1

        # Handle deletion if the middle node is the head
        if temp.prev is None:
            self.head = temp.next
            if self.head:
                self.head.prev = None
        else:
            # Adjust pointers to skip the middle node
            temp.prev.next = temp.next
        if temp.next:
            temp.next.prev = temp.prev

    def delete_pos(self, pos):
        # Delete a node at a specific position
        temp = self.head
        count = 1

        # Handle deletion if the position is the head
        if pos == count:
            self.head = temp.next
            if self.head:
                self.head.prev = None
            return

        # Traverse to the specified position
        while temp:
            if pos == count:
                # Adjust pointers to remove the node
                temp.prev.next = temp.next
                if temp.next:
                    temp.next.prev = temp.prev
                return
            temp = temp.next
            count += 1

            # If position is invalid
            if temp is None:
                print("Enter a valid position!")
                return
            
    def search(self, value):
        # Search for a node with the given value in the linked list
            temp = self.head
            while temp:
                if temp.data == value:
                    print(f"Node {value} exists")
                    return 
                temp = temp.next
            print(f"{value} does not exist")
            return

# Example usage
ll = DoublyLinkedList()

# Create nodes
n1 = Node(10)
n2 = Node(20)
n3 = Node(30)
n4 = Node(40)
n5 = Node(50)

# Append nodes
ll.append(n1)
ll.append(n2)
ll.append(n3)
ll.append(n4)
ll.append(n5)

# Original list
print("Original List:")
ll.print()
print()

# Reverse the list
print("List after reversing:")
ll.reverse()
ll.print()
print()

# Insert a node at the beginning
print("List after inserting 5 at the beginning:")
ll.insert_begin(Node(5))
ll.print()
print()

# Count nodes in the list
print(f"Number of nodes in the list: {ll.count()}")
print()

# Search for a node
print("Searching for 30:")
ll.search(30)
print("Searching for 100:")
ll.search(100)
print()

# Delete the middle node
print("List after deleting the middle node:")
ll.delete_middle()
ll.print()
print()

# Delete a node at a specific position
print("List after deleting node at position 2:")
ll.delete_pos(2)
ll.print()
print()

print("List after deleting node at position 1:")
ll.delete_pos(1)
ll.print()
print()

# ll = DoublyLinkedList()
# n1 = Node(10)
# n2 = Node(20)
# n3 = Node(30)
# n4 = Node(40)
# n5 = Node(50)
# ll.append(n1)
# ll.append(n2)
# ll.append(n3)
# ll.append(n4)
# ll.append(n5)
# ll.print()
# print()
# print()

# ll.print()
# print()
# print()

# ll.print()
# print()
# print()
# ll.reverse()
# ll.print()
# print()
# ll.count()
# print()
# ll.delete_middle()
# ll.print()