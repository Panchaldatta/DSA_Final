# Binary Search Tree
# Write a program to perform the following operations on a Binary Search Tree:
# • Insert a node into the BST. (Easy)
# • Find the minimum value in the BST. (Easy)
# • Find the maximum value in the BST. (Easy)
# • Search for a specific node and print it’s level. (Medium)
# • Count the number of nodes in the BST. (Medium)
# • Count the number of nodes in left subtree. (Medium)
# • Count the number of nodes in right subtree. (Medium)




class BinarySearchTree:
    def __init__(self, data):
        self.left = None
        self.data = data
        self.right = None

    # def insert_node(self,new_node):
    #     if new_node.data<self.data:
    #         if self.left is None:
    #             self.left=new_node
    #             print(f"Node inserted: {new_node.data}")
    #         else:
    #             self.left.insert_node(new_node)
    #     else:





    def insert_node(self, new_node):
        if new_node.data < self.data:  # for inserting node at left
            if self.left is None:   # if there is no node at left
                self.left = new_node
                print(f"Node is inserted : {new_node.data}")
            else:  # if there is already a node at left
                self.left.insert_node(new_node)   # call the function again
        else:   # for inserting node at right
            if self.right is None:   # if there is no node at right
                self.right = new_node
                print(f"Node is inserted : {new_node.data}")
            else:  # if there is already a node at right
                self.right.insert_node(new_node)   # call the function again
                                     
    def count_nodes(self):
        count = 1
        if self.left:
            count += self.left.count_nodes()
              # increment count every time new function is called
        # if self.right:
        #     count += self.right.count_nodes()
        return count
    
    def count_right(self):
        count = 1
        if self.right:
            count += self.right.count_nodes()
        return count
    
    def count_left(self):
        count = 1
        if self.left:
            count += self.left.count_nodes()
        return count

    def min_value(self):
        if self.left is None:  # we get minimum value
            print(f"Minimum value in the tree is {self.data}")
            return
        else:  # we keep traversing on left side
            self.left.min_value()

    def max_value(self):
        if self.right is None:  # we get minimum value
            print(f"Maximum value in the tree is {self.data}")
            return
        else:  # we keep traversing on right side
            self.right.max_value()
    
    def search_lvl(self, val, level=1):  # Pass level as a parameter
        if self.data == val:  # If node exists in the tree
            print(f"{val} exists at level {level}")
            return level
        elif val < self.data:  # For left child
            if self.left:  # Move to left side of tree
                return self.left.search_lvl(val, level + 1)  # Pass level + 1 to left subtree
            else:
                print(f"{val} does not exist")
                return 
        else:  # For right child
            if self.right:  # Move to right side of tree
                return self.right.search_lvl(val, level + 1)  # Pass level + 1 to right subtree
            else:
                print(f"{val} does not exist")
                return 

bst = BinarySearchTree(25)
bst.insert_node(BinarySearchTree(15))
bst.insert_node(BinarySearchTree(30))
bst.insert_node(BinarySearchTree(4))
bst.insert_node(BinarySearchTree(35))
bst.insert_node(BinarySearchTree(20))
print()
print(bst.count_nodes())
print()
bst.min_value()
print()
bst.max_value()
print()
print()
bst.search_lvl(20)
print()
print("The values in right sub tree are: ",bst.count_right())
print("The values in left sub tree are: ",bst.count_left())