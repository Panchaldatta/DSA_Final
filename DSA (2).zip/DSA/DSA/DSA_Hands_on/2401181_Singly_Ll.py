class Node:
    def __init__(self, data):
        self.data = data  
        self.next = None  
          

class SinglyLinkedList:
    def __init__(self):
        self.head = None  # assign 'head' as null initially

    def append(self, node_value):  # method to append elements at end of singly linked list
        temp = self.head  # points to 1st node
        if temp:
            while temp.next:  # find last node
                temp = temp.next
            temp.next = node_value  # appending new node
        else:
            self.head = node_value  # add first node to the singly linked list

    def insert(self, node_value, pos):  # method to insert element at specified position
        temp = self.head
        count = 1
        if pos == 1:
            node_value.next = self.head  # making new node as head
            self.head = node_value
        else:
            while temp:
                if count+1 == pos:  # to stop the singly linked list at 1 node before
                    node_value.next = temp.next
                    temp.next = node_value
                    return
                else:  # keep traversing
                    temp = temp.next
                    count += 1
                if temp is None:  # element not found in the singly linked list
                    print("Please enter a valid position")
                    return
    
    def delete_last(self):
        # If the list is empty, do nothing
        if not self.head:
            return

        # If there's only one node, delete it
        if not self.head.next:
            self.head = None
            return

        # Traverse the list to find the second-to-last node
        temp = self.head
        while temp.next and temp.next.next:
            temp = temp.next

        # Remove the last node
        temp.next = None

        

    def print(self):  # method to print elements of singly linked list
        temp = self.head
        while temp:
            print(temp.data, end=" ")
            temp = temp.next

    

    def count(self):  # method to get the count of nodes in the singly linked list
        temp = self.head
        count = 0
        while temp:
            count += 1
            temp = temp.next
        return count
    
    def min_max(self):  # method to get the min and max element in the singly linked list
        temp = self.head
        minimum, maximum = temp.data, temp.data  # min and max will point to the first node data
        while temp:
            if temp.data < minimum:
                minimum = temp.data
            if temp.data > maximum:
                maximum = temp.data
            temp = temp.next
        return minimum, maximum
    
    def search(self, value):
        # Search for a node with the given value in the linked list
        temp = self.head
        while temp:
            if temp.data == value:
                print(f"Node {value} exists")
                return 
            temp = temp.next
        print(f"{value} does not exist")
        return
            
    def merge(self, other):
        # Merge another linked list into this linked list
        if not self.head:  # If current list is empty, set head to other list's head
            self.head = other.head
            return
        if not other.head:  # If other list is empty, do nothing
            return
        else:
            temp = self.head
            while temp:
                if temp.next is None:  # Find the end of the current list
                    temp.next = other.head  # Attach other list at the end
                    return
                temp = temp.next
        
    def reverse(self):
        # Reverse the linked list
        temp = self.head
        prev = None
        while temp:
            next_node = temp.next  # Store the next node
            temp.next = prev  # Reverse the current node's pointer
            prev = temp  # Move prev to the current node
            temp = next_node  # Move to the next node
        self.head = prev  # Update the head to the new first node
        
    def evenOdd(self):
        # Count even and odd numbers in the linked list
        temp = self.head
        even_count = 0
        odd_count = 0
        while temp:
            if temp.data % 2 == 0:  # Check if the node's data is even
                even_count += 1
            else:  # Otherwise, it's odd
                odd_count += 1
            temp = temp.next 
        return even_count, odd_count

ll = SinglyLinkedList()
n1 = Node(1)
n2 = Node(2)
n3 = Node(3)
n4 = Node(4)
ll.append(n1)
ll.append(n2)
ll.append(n3)
ll.append(n4)
print(f"First linked list: ",end="")
ll.print()
print()
print()
ll2 = SinglyLinkedList()
n5 = Node(5)
n6 = Node(6)
n7 = Node(7)
n8 = Node(8)
ll2.append(n5)
ll2.append(n6)
ll2.append(n7)
ll2.append(n8)
print("Second linked list: ",end="")
ll2.print()
print()
print()
print("List before inserting: ",end="")
ll.print()
print()
print()
ll.insert(Node(15), 2)
print("List after inserting: ",end="")
ll.print()
print()
print()
ll.delete_last()
print()
ll.print()
print()
ll.search(50)
print()
min , max = ll.min_max()
print(f"The linked list's maximum value is {max} and minimum value is {min}")
even , odd = ll.evenOdd()
print(f"The number of even value nodes are {even} and odd value nodes are {odd}")
print()
ll.merge(ll2)
print("The merged list is: ", end = "")
ll.print()
print()
print("List before reversing: ", end = "")
ll.print()
ll.reverse()
print()
print("List after reversing: ", end = "")
ll.print()